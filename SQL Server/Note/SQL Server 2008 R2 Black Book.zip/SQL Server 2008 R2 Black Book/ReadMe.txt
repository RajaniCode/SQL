*******************************************************************************
SQL Server 2008 R2 - Black Book
CD�ROM CONTENTS
*******************************************************************************

The companion CD-ROM contains complete source code for the examples in the book, organized by chapters. 

Note: The SQL Server 2008 R2 and Visual Studio 2008 (not included on this CD-ROM) is required to complete the examples in this book.

Installing the Examples 

This CD holds the source code for the examples in the book. Each chapter folder contains a (.sql) script file that holds the SQL queries for the chapter. The chapter folder can also contain different application folders consisting applications created using Visual Studio 2008. In addition, in some chapter folders you can find a text file containing the commands to be run on a Command Prompt. 

For example, in the Chapter 25 folder, you will find a Chapter 25.sql script file, two application folders namely - FileUser and ImplementingCAS, and a Chapter 25.txt text file. 


It's important to realize that Microsoft Windows marks all files from a CD as read-only, by default, which means they'll be marked as read-only when you copy them onto your hard drive (there's no way to avoid this when you're copying files from a CD in Windows). You can remove the read-only attribute by selecting files in the Windows Explorer (either singly or in groups) right-clicking them, selecting the 'Properties' item, and deselecting the read-only attribute in the Properties dialog box that opens. 

Finally, and most importantly...Happy Programming!

Limits of Liability & Disclaimer of Warranty

Although the author and publisher have taken every precaution when preparing this disk, they make no expressed or implied warranty of any kind and assume no responsibility for errors or omissions.