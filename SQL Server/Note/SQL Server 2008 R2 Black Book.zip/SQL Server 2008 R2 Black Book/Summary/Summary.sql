--Listing B.1: 
CREATE TABLE Spt_geometry
(id int IDENTITY (1,1),
Spt_Col1 geometry,
Spt_Col2 AS Spt_Col1.STAsText())

--Listing B.2: 
INSERT INTO Spt_geometry (Spt_Col1)
VALUES (geometry::STGeomFromText('LINESTRING (60 20, 20 20, 60 60)', 0))
INSERT INTO Spt_geometry (Spt_Col1)
VALUES (geometry::STGeomFromText('POLYGON ((0 0, 90 0, 90 90, 0 90, 0 0))', 0))

--Listing B.3: 
SELECT * FROM Spt_geometry

--Listing B.4: 
CREATE TABLE Spt_geography
(id int IDENTITY (1,1),
Spt_Col1 geography,
Spt_Col2 AS Spt_Col1.STAsText())

--Listing B.5: 
INSERT INTO Spt_geography (Spt_Col1)
VALUES (geography::STGeomFromText('LINESTRING(20 50, 30 70)', 4326))
INSERT INTO Spt_geography (Spt_Col1)
VALUES (geography::STGeomFromText('POLYGON((30 80, 40 70, 50 60, 60 90, 30
80))', 4326))

--Listing B.6: 
SELECT * FROM Spt_geography


--Listing 4.1: 
SELECT OrderID, SUM(Quantity) AS Quantity FROM OrderDetails GROUP BY OrderID
HAVING SUM(Quantity) > 30 ORDER BY OrderID ASC

--Listing 4.2: 
INSERT INTO Customers (CustomerID, CustName, CustCompanyName, CustDesignation,
CustAddress, CustCity, CustState, CustPostalCode, CustCountry, CustPhone)
VALUES (406, 'Marie Bertrand', 'Que Delicia', 'Marketing Assistant', 'Gran Via,
1', 'Anchorage', 'Alaska', 99407, 'USA', '(906) 555-5749')

--Listing 4.3: 
UPDATE Customers
SET CustCompanyName = 'Quick-Stop', CustAddress = 'P.O. Box 555'
WHERE CustomerID = 405

--Listing 4.4: 
DELETE FROM Customers
WHERE CustomerID = 406

--Listing 4.5: 
SELECT ProductID, UnitsInStock + 10 AS UnitsInStock, UnitPrice * 2 AS UnitPrice
FROM Products

--Listing 4.6: 
SELECT * FROM Products WHERE SupplierID = 101 AND UnitPrice < 20

--Listing 4.7: 
SELECT * FROM Customers WHERE CustCountry IN ('USA', 'Canada', 'Brazil') AND
CustDesignation = 'Sales Manager' OR CustDesignation = 'Accounting Manager'

--Listing 4.8: 
SELECT CustID = CustomerID, Name = CustName, CustAddress, CustCity, CustCountry
FROM Customers

--Listing 4.9: 
UPDATE Products
SET UnitPrice += UnitPrice * 5 / 100, UnitsInStock *= 2

--Listing 4.10: 
SELECT UnitsInStock & UnitsOnOrder AS Units FROM Products WHERE ProductID = 2

--Listing 4.11: 
SELECT ProductID, -UnitsInStock AS UnitsInStock FROM Products WHERE ProductID = 3

--Listing 4.12: 
SELECT EmpID, FirstName + ' ' + LastName AS Name, Department, Salary FROM
Employees

--Listing 4.13: 
DECLARE @id hierarchyid
SELECT @id = hierarchyid::GetRoot()
PRINT 'The root of the hierarchy is: ' + @id.ToString()

--Listing 4.14: 
SELECT COUNT(ProductID) AS COUNT, MIN(UnitPrice) AS MIN, SUM(UnitsInStock) AS SUM
FROM Products

--Listing 4.15: 
Declare @var1 int = 25
Declare @var2 datetime = GETDATE()
Declare @var3 varchar(50)= 'Using Scalar Functions'
SELECT SQRT(@var1) AS FirstColumn, Year(@var2) AS SecondColumn, SUBSTRING(@var3,
6, 17) AS ThirdColumn

--Listing 4.16: 
SELECT * FROM OPENDATASOURCE('SQLNCLI',
'Data Source=JITENDRA;Integrated Security=SSPI')
.Inventory.dbo.Employees

--Listing 4.17: 
SELECT OrderID, ProductID, Quantity,
RANK() OVER (PARTITION BY OrderID ORDER BY Quantity DESC) AS 'RANK'
FROM OrderDetails


--Listing 5.1: 
SELECT CustomerID, CAST(CustName AS varchar(50)) AS Name FROM Customers

--Listing 5.2: 
SELECT EmpID, CONVERT(varchar(50), HireDate, 101) AS HireDate FROM Employees

--Listing 5.3: 
BEGIN TRANSACTION
BEGIN
INSERT INTO Employees (EmpID, FirstName, LastName, Department, Salary,
HireDate) VALUES(506, 'Mark', 'Anthony', 'Sales', 20000, GETDATE())
COMMIT TRANSACTION
END

--Listing 5.4: 
IF (SELECT COUNT(*) FROM Customers WHERE CustCountry = 'Brazil') <> 0
SELECT CustomerID, CustName, CustAddress, CustCity, CustState, CustCountry FROM
Customers WHERE CustCountry = 'Brazil'
ELSE
PRINT 'No customer of Brazil!'

--Listing 5.5: 
DECLARE @count AS int = 1
WHILE @count < 10
BEGIN
SET @count += 1
IF @count = 3
CONTINUE
IF @count = 8
BREAK
PRINT 'Value of counter is: ' + CONVERT(varchar(12), @count)
END

--Listing 5.6: 
DECLARE @count AS int = 1
WHILE @count < 10
BEGIN
SET @count += 1
IF @count = 5 GOTO Label2 -- Jumping to Label2
IF @count = 6 GOTO Label1 -- This line will never execute
END
Label1:
PRINT 'Label1 is executing'
Label2:
PRINT 'Label2 is executing'

--Listing 5.7: 
CREATE PROCEDURE sp_ReturnStatement
AS
IF (SELECT COUNT(CustomerID) FROM Customers) < 10
RETURN 1
ELSE
RETURN 2
GO
DECLARE @result AS int
EXECUTE @result = sp_ReturnStatement
PRINT 'Value returned is: ' + CONVERT(varchar(12), @result)
GO

--Listing 5.8: 
CREATE PROCEDURE sp_WaitFor
AS
SELECT * FROM Customers WHERE CustomerID = 404
GO
BEGIN
WAITFOR DELAY '00:02'
EXECUTE sp_WaitFor
END
GO

--Listing 5.9: 
CREATE TABLE ProductsMaster(ProductID int, ProductName varchar(20))
CREATE TABLE NewProducts(ProductID int, ProductName varchar(20))
INSERT INTO ProductsMaster
VALUES(1, 'Chocolate'), (2, 'Perth Pasties'), (3, 'Ipoh Coffee'), (4, 'Scottish
Longbreads')
INSERT INTO NewProducts
VALUES(1, 'Chocolate'), (5, 'Boston Crab Meat')

--Listing 5.10: 
SELECT * FROM ProductsMaster

--Listing 5.11: 
SELECT * FROM NewProducts

--Listing 5.12: 
MERGE ProductsMaster AS target
USING (SELECT ProductID, ProductName FROM NewProducts) AS source
ON target.ProductID = source.ProductID
WHEN MATCHED THEN
UPDATE SET target.ProductName = source.ProductName
WHEN NOT MATCHED THEN
INSERT (ProductID, ProductName) VALUES (source.ProductID, source.ProductName);

--Listing 5.13: 
SELECT TOP(3) CustomerID, CustName, CustAddress, CustCity, CustState, CustCountry
FROM Customers

--Listing 5.14: 
CREATE TABLE Customers_USA(CustID int, Name varchar(20))
CREATE TABLE Customers_UK(CustID int, Name varchar(20))
INSERT INTO Customers_USA
VALUES(401, 'Rene Philips'), (402, 'Paula Wilson'), (403, 'Joleen Mathews'),
(404, 'Mark Anthony')
INSERT INTO Customers_UK
VALUES(501, 'Mark Thompson'), (502, 'Maria Joseph'), (503, 'Ariya Vincent'),
(504, 'Christeen Ferrari')

--Listing 5.15: 
SELECT * FROM Customers_USA
UNION
SELECT * FROM Customers_UK

--Listing 5.16: 
SELECT ProductID FROM Products
EXCEPT
SELECT ProductID FROM OrderDetails

--Listing 5.17: 
SELECT ProductID FROM Products
INTERSECT
SELECT ProductID FROM OrderDetails

--Listing 5.18: 
CREATE DATABASE Test

--Listing 5.19: 
DROP DATABASE Test

--Listing 5.20: 
CREATE TABLE Users(UserID int, Name nvarchar(30), UserAddress nvarchar(50))

--Listing 5.21: 
INSERT INTO Users(UserID, Name, UserAddress)
VALUES (101, 'Maria Anders', 'Obere Str. 57')

--Listing 5.22: 
SELECT * FROM Users

--Listing 5.23: 
ALTER TABLE Users DROP COLUMN UserAddress

--Listing 5.24: 
TRUNCATE TABLE Users

--Listing 5.25: 
DROP TABLE Users




--Listing 6.1:

CREATE TABLE SuppliersSample(
SupplierID int NOT NULL CONSTRAINT pkSuppID PRIMARY KEY,
SupplierName nvarchar(40) NOT NULL,
SupplierContactName nvarchar(30) NULL,
SupplierContactDesignation nvarchar(30) NULL,
SupplierAddress nvarchar(100) NULL,
SupplierCity nvarchar(30) NULL,
SupplierState nvarchar(30) NULL,
SupplierPostalCode nvarchar(10) NULL,
SupplierCountry nvarchar(30) NULL,
SupplierPhone nvarchar(25) NULL)

--Listing 6.2: 

CREATE TABLE SuppliersSample(
SupplierID int NOT NULL CONSTRAINT pkSuppID PRIMARY KEY,
SupplierName nvarchar(40) NOT NULL,
SupplierContactName nvarchar(30) NULL,
SupplierContactDesignation nvarchar(30) NULL,
SupplierAddress nvarchar(100) NULL,
SupplierCity nvarchar(30) NULL,
SupplierState nvarchar(30) NULL,
SupplierPostalCode nvarchar(10) NULL,
SupplierCountry nvarchar(30) NULL,
SupplierPhone nvarchar(25) NULL CONSTRAINT uqSuppID UNIQUE)

--Listing 6.3: 

CREATE TABLE ProductsSample(
ProductID int NOT NULL CONSTRAINT pkProdID PRIMARY KEY,
ProductName nvarchar(50) NOT NULL,
SupplierID int NOT NULL CONSTRAINT fkSuppID REFERENCES SuppliersSample
(SupplierID),
UnitPrice money NOT NULL,
UnitsInStock smallint NULL,
UnitsOnOrder smallint NULL,
ReorderLevel smallint NULL,
Discontinued bit NOT NULL)

--Listing 6.4: 

CREATE TABLE ProductsSample(
ProductID int NOT NULL CONSTRAINT pkProdID PRIMARY KEY,
ProductName nvarchar(50) NOT NULL,
SupplierID int NOT NULL CONSTRAINT fkSuppID REFERENCES SuppliersSample
(SupplierID),
UnitPrice money NOT NULL,
UnitsInStock smallint NULL,
UnitsOnOrder smallint NULL,
ReorderLevel smallint NULL CONSTRAINT chkReorderLvl CHECK (ReorderLevel >= 0
and ReorderLevel <= 50),
Discontinued bit NOT NULL)

--Listing 6.5: 

CREATE RULE ReorderLvl_chk AS @reordlvl BETWEEN 0 and 50

--Listing 6.6: 

sp_bindrule ReorderLvl_chk, 'ProductsSample.ReorderLevel'

--Listing 6.7: 

sp_unbindrule 'ProductsSample.ReorderLevel'

--Listing 6.8: 

DROP RULE ReorderLvl_chk

--Listing 6.9: 

SELECT p.ProductID, p.ProductName, p.UnitPrice,
s.SupplierName, s.SupplierContactName, s.SupplierPhone
FROM Products p
CROSS JOIN Suppliers s

--Listing 6.10: 

SELECT p.ProductID, p.ProductName, p.UnitPrice,
s.SupplierName, s.SupplierContactName, s.SupplierPhone
FROM Products p
INNER JOIN Suppliers s
ON p.SupplierID = s.SupplierID

--Listing 6.11: 

SELECT s.SupplierName, s.SupplierContactName, s.SupplierPhone,
p.ProductID, p.ProductName, p.UnitPrice
FROM Suppliers s
LEFT OUTER JOIN Products p
ON s.SupplierID = p.SupplierID

--Listing 6.12: 

SELECT p.ProductID, p.ProductName, p.UnitPrice,
s.SupplierName, s.SupplierContactName, s.SupplierPhone
FROM Products p
RIGHT OUTER JOIN Suppliers s
ON p.SupplierID = s.SupplierID

--Listing 6.13: 

SELECT p.ProductID, p.ProductName, p.UnitPrice,
s.SupplierName, s.SupplierContactName, s.SupplierPhone
FROM Products p
FULL OUTER JOIN Suppliers s
ON p.SupplierID = s.SupplierID

--Listing 6.14: 

SELECT e.FirstName + ' ' + e.LastName AS Employee,
emp.FirstName + ' ' + emp.LastName AS Manager
FROM Employees AS e
LEFT OUTER JOIN Employees AS emp
ON e.ManagerID = emp.EmpID

--Listing 6.15: 

CREATE VIEW vw_Suppliers
AS
SELECT SupplierID, SupplierName, SupplierContactName, SupplierContactDesignation,
SupplierAddress, SupplierPhone
FROM Suppliers
WHERE SupplierCity='Manchester'

--Listing 6.16: 

ALTER VIEW vw_Suppliers
AS
SELECT SupplierID, SupplierName, SupplierContactName, SupplierContactDesignation,
SupplierAddress, SupplierPhone
FROM Suppliers
WHERE SupplierCity='Manchester'
AND SupplierContactDesignation ='Export Administrator'

--Listing 6.17: 

drop view vw_Suppliers

--Listing 6.18: 

SELECT * FROM Suppliers
WHERE SupplierCity IN
(SELECT SupplierCity FROM Suppliers
WHERE SupplierName = 'Star Biscuits, Ltd.')

--Listing 6.19: 

SELECT c.CustomerID, c.CustName, c.CustCompanyName,
COUNT(o.OrderID) AS TotalOrders
FROM Customers c LEFT OUTER JOIN
(SELECT * FROM Orders WHERE YEAR (Orders.OrderDate) = 1996) AS o
ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID, c.CustName, c.CustCompanyName

--Listing 6.20: 

WITH OrdCust_CTE (CustomerID, CustName, CustCompanyName, TotalOrders)
AS
(
SELECT c.CustomerID, c.CustName, c.CustCompanyName, COUNT(o.OrderID) AS
TotalOrders
from Customers c LEFT OUTER JOIN
Orders o ON c.CustomerID = o.CustomerID
group by c.CustomerID, c.CustName, c.CustCompanyName
)
SELECT * FROM OrdCust_CTE
ORDER BY CustomerID;

--Listing 6.21: 

SELECT OrderID, ProductID, UnitPrice, Quantity, Discount,
(UnitPrice * Quantity) - (UnitPrice * Quantity * Discount) AS 'Total Cost'
FROM OrderDetails



--Listing 7.1: 

CREATE PROCEDURE GetOrderDetails
AS
SELECT * FROM OrderDetails
GO

--Listing 7.2: 

ALTER PROCEDURE GetOrderDetails
AS
SELECT OrderID, SUM(UnitPrice) AS UnitPrice, SUM(Quantity) AS Quantity
FROM OrderDetails Group By OrderID
GO

--Listing 7.3: 

EXECUTE GetOrderDetails

--Listing 7.4: 

DROP PROCEDURE GetOrderDetails

--Listing 7.5: 

CREATE PROCEDURE GetOrdersCustomers
@MinFreightCharge money,
@DestinationCountry nvarchar(30)
AS
SELECT o.OrderID, c.CustomerID, o.FreightCharges, c.CustCountry
FROM Orders o, Customers c
WHERE o.CustomerID=c.CustomerID
AND o.FreightCharges > @MinFreightCharge
AND c.CustCountry = @DestinationCountry
GO

--Listing 7.7: 

CREATE TYPE Employee_Type AS TABLE
(
EmpID int NOT NULL PRIMARY KEY,
FirstName nvarchar(30) NOT NULL,
LastName nvarchar(30) NULL,
Department nvarchar(50) NOT NULL,
ManagerID int NULL,
Salary money NOT NULL,
HireDate datetime NOT NULL
)

--Listing 7.8: 

CREATE PROCEDURE InsertEmployees
@EmployeeDetails_TVP Employee_Type READONLY
AS
INSERT INTO Employees
(EmpID,FirstName,LastName,Department,ManagerID,Salary,HireDate)
SELECT * FROM @EmployeeDetails_TVP
SELECT * FROM @EmployeeDetails_TVP
SELECT * FROM Employees
GO

--Listing 7.9: 

DECLARE @EmpDetails AS Employee_Type
INSERT INTO @EmpDetails
(EmpID,FirstName,LastName,Department,ManagerID,Salary,HireDate)
VALUES (506, 'George', 'Fernandes', 'Sales', 502, 15000, 6/6/2009)
EXECUTE InsertEmployees @EmpDetails

--Listing 7.10: 

CREATE PROCEDURE GetProductQuantity
@PID int, --input parameter
@price money, --input parameter
@min int OUTPUT, --output parameter
@max int OUTPUT--output parameter
AS
SELECT ProductID,count(OrderID) AS 'Total orders'
FROM OrderDetails
WHERE ProductID=@PID and UnitPrice=@price
GROUP BY ProductID
SELECT @max=max(Quantity) FROM OrderDetails
WHERE ProductID=@PID and UnitPrice=@price
SELECT @min=min(Quantity) FROM OrderDetails
WHERE ProductID=@PID and UnitPrice=@price
GO

--Listing 7.12: 

CREATE FUNCTION FuncGetTotalOrderCost(@OrderID int)
RETURNS money
AS
BEGIN
DECLARE @TotCost money
SELECT @TotCost = sum((UnitPrice * Quantity) - (UnitPrice * Quantity *
Discount))
FROM OrderDetails
WHERE OrderID = @OrderID
RETURN @TotCost
END

--Listing 7.13: 

select dbo.FuncGetTotalOrderCost(701) as 'Total Cost'

--Listing 7.14: 

CREATE FUNCTION FuncGetOrderDetails
(@OrderID int, @ProductID int)
RETURNS @Result TABLE
(
OrderID int primary key NOT NULL,
ProductID int NOT NULL,
UnitPrice money NOT NULL,
Quantity smallint NOT NULL,
Discount real NOT NULL,
NetAmount money NOT NULL
)
AS
BEGIN
DECLARE @UnitPrice AS real, @Quantity AS int, @Discount AS real, @DiscAmt AS real,
@NetAmt AS real
SELECT @UnitPrice= UnitPrice, @Quantity =Quantity, @Discount =Discount
FROM OrderDetails WHERE OrderID=@OrderID AND ProductID =@ProductID
SET @DiscAmt = (@UnitPrice * @Quantity) * @Discount
SET @NetAmt =(@UnitPrice * @Quantity) - @DiscAmt
INSERT INTO @Result
SELECT OrderID, ProductID, UnitPrice, Quantity, Discount, @NetAmt FROM
OrderDetails
WHERE OrderID=@OrderID AND ProductID=@ProductID
RETURN
END
GO


--Listing 8.1: 
CREATE TRIGGER Insert_Products
ON Products
AFTER
INSERT
AS
PRINT 'Record inserted in the Products table!'

--Listing 8.2: 
INSERT INTO Products(ProductID, ProductName, SupplierID, UnitPrice, UnitsInStock,
UnitsOnOrder, ReorderLevel, Discontinued)
VALUES(6, 'Perth Pasties', 102, 18.3276, 20, 0, 10, 'TRUE')

--Listing 8.3: 
CREATE TRIGGER Delete_Products
ON Products
INSTEAD OF
DELETE
AS
PRINT 'You are not allowed to delete a record from the Products table!'

--Listing 8.4: 
DELETE FROM Products
WHERE ProductID = 5

--Listing 8.6: 
CREATE ASSEMBLY RecentRow
FROM 'D:\Books\Black Book\SQL Server 2008 R2 Black Book\Applications\Chapter
8\CLRTrigger\CLRTrigger\bin\Debug\CLRTrigger.dll'

--Listing 8.7: 
CREATE TRIGGER CLRTrigger
ON Products
AFTER INSERT
AS
EXTERNAL NAME RecentRow.[CLRTrigger.Triggers].GetLastRow

--Listing 8.8: 
INSERT INTO Products(ProductID, ProductName, SupplierID, UnitPrice,
UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued)
VALUES(7, 'Ipoh Coffee', 104, 22.5485, 25, 0, 20, 'FALSE')

--Listing 8.9: 
CREATE TRIGGER Alter_Database_Table
ON DATABASE
AFTER ALTER_TABLE
AS
PRINT 'A table in the current database is modified!'

--Listing 8.10: 
ALTER TABLE Employees
ADD EmpPhone nvarchar(25) NULL

--Listing 8.11: 
CREATE TRIGGER Connection_Limit
ON ALL SERVER WITH EXECUTE AS 'Jitendra\Jitendra Arya'
FOR LOGON
AS
BEGIN
IF ORIGINAL_LOGIN() = 'Jitendra\Jitendra Arya'
AND (SELECT COUNT(*) FROM sys.dm_exec_sessions
WHERE is_user_process = 1 AND original_login_name = 'Jitendra\Jitendra Arya') >
1
ROLLBACK
END

--Listing 8.12: 
ALTER TRIGGER Insert_Products
ON Products
INSTEAD OF
INSERT
AS
PRINT 'An attempt was made to insert records into the Products table!'

--Listing 8.13: 
INSERT INTO Products(ProductID, ProductName, SupplierID, UnitPrice, UnitsInStock,
UnitsOnOrder, ReorderLevel, Discontinued)
VALUES(8, 'Chocolade', 103, 15.6294, 50, 25, 20, 'TRUE')

--Listing 8.14: 
DROP TRIGGER Alter_Database_Table
ON DATABASE


--Listing 9.1: 

DECLARE @orderid int, @totalcost money
DECLARE TotalCost_cursor CURSOR
STATIC
FOR
SELECT OrderID, sum (UnitPrice * Quantity) AS 'Total Cost' FROM OrderDetails
GROUP BY OrderID
OPEN TotalCost_cursor
PRINT '------------------------------------------------------------'
PRINT 'The following displays the total cost for each order placed:'
PRINT '------------------------------------------------------------'
FETCH NEXT FROM TotalCost_cursor INTO @orderid, @totalcost
WHILE @@FETCH_STATUS = 0
BEGIN
PRINT ' | OrderID - ' + CAST(@OrderID AS varchar) + ' | Total Cost - ' +
CAST(@totalcost AS varchar) + ' | '
FETCH NEXT FROM TotalCost_cursor INTO @orderid, @totalcost
PRINT '--------------------------------------------------'
END
CLOSE TotalCost_cursor
DEALLOCATE TotalCost_cursor
GO


--Listing 9.2: 

/*********************/
/* Markup All Titles */
/*********************/
/* Declare a cursor to get a list of titles */
DECLARE c_Titles CURSOR FORWARD_ONLY KEYSET
FOR SELECT title,
price,
ytd_sales
FROM titles
WHERE price IS NOT NULL
/* Declare variables to hold the price information */
DECLARE @v_Title VARCHAR(80),
@v_Price Money,
@v_YTD MONEY,
@v_TotYTD MONEY,
@v_NewPrice MONEY
/* Get Total YTD Sales */
SELECT @v_TotYTD = SUM(COALESCE(ytd_sales,0))
FROM pubs.dbo.titles
/* Open the cursor */
OPEN c_Titles
/* Get the first title name */
FETCH NEXT FROM c_Titles INTO @v_Title,
@v_Price,
@v_YTD
/* Loop through the titles */
WHILE (@@Fetch_Status <> -1)
BEGIN
/* Check for deleted row */
IF (@@Fetch_Status <> -2)
BEGIN
/* Calculate New Price */
Select @v_NewPrice = @v_Price + ((@v_Price * 10) /100)
/* Display the markup being performed */
PRINT 'Marking up: ' + @v_Title
PRINT 'Old Price: ' + CONVERT(VARCHAR,@v_Price)
PRINT 'New Price: ' + CONVERT(VARCHAR,@v_NewPrice)
PRINT ''
PRINT ''
/* Perform the update */
UPDATE pubs.dbo.titles
SET price = @v_NewPrice
WHERE CURRENT OF c_Titles
END
/* Get the next title from the cursor */
FETCH NEXT FROM c_Titles INTO @v_Title,
@v_Price,
@v_YTD
END
/* Close and deallocate the cursor */
CLOSE c_Titles
DEALLOCATE c_Titles
GO


--Listing 9.3: 

/* Clone author records to create duplicate entries */
INSERT INTO authors ( au_id,
au_lname,
au_fname,
phone,
address,
city,
state,
zip,
contract )
SELECT '0' + SUBSTRING(au_id, 2, 10),
au_lname,
au_fname,
phone,
address,
city,
state,
zip,
contract
FROM authors
WHERE substring(au_id,1,1)<>'0'


--Listing 9.4: 

/****************************/
/* Remove Duplicate Authors */
/****************************/
/* Switch database context */
USE pubs
/* Declare a cursor to get a list of authors */
DECLARE c_Authors CURSOR FORWARD_ONLY KEYSET
FOR SELECT au_fname + ' ' + au_lname
FROM authors
ORDER BY au_lname, au_fname
-- ORDER BY au_lname DESC, au_fname DESC
/* Declare variables to hold the current and previous author names */
DECLARE @v_name varchar(50),
@v_oldname varchar(50)
/* Open the cursor */
OPEN c_Authors
/* Get the first author name */
FETCH NEXT FROM c_Authors INTO @v_name
/* Loop through the authors */
WHILE (@@Fetch_Status <> -1)
BEGIN
/* Check for deleted row */
IF (@@Fetch_Status <> -2)
BEGIN
/* Remove duplicate entries */
IF (@v_oldname = @v_name)
BEGIN
/* Remove duplicate row */
DELETE FROM pubs.dbo.authors
WHERE CURRENT OF c_Authors
/* Show records removed */
PRINT @v_name + ' (Duplicate Removed)'
END
/* Save name to check for duplicate entries */
SELECT @v_oldname = @v_name
END
/* Get the next author name from the cursor */
FETCH NEXT FROM c_Authors INTO @v_name
END
/* Close and deallocate the cursor */
CLOSE c_Authors
DEALLOCATE c_Authors
GO


--Listing 9.5: 

SELECT au_fname + ' ' + au_lname
FROM authors
ORDER BY au_lname DESC, au_fname DESC



--Listing 9.6: 

/********************************************************/
/* Select a random employee to receive a couple movie ticket */
/********************************************************/
/* Declare cursor to select a list of employees */
DECLARE c_RandomEmployee CURSOR READ_ONLY STATIC SCROLL FOR
SELECT EmpID, FirstName + ' ' + LastName AS EmpName
FROM Employees
/* Declare variables */
DECLARE @v_EmpID INT,
@v_EmpName varchar(40),
@v_EmpCount INT,
@v_WinnerRow INT,
@v_Msg VARCHAR(1000)
/* Open the cursor */
OPEN c_RandomEmployee
/* Get the number of employees qualified by the cursor */
SELECT @v_EmpCount = @@CURSOR_ROWS
/* If we have at least one employee, then we can continue processing */
IF (@v_EmpCount <> 0)
BEGIN
/* Select the row for our random winner */
SELECT @v_WinnerRow = CONVERT(INT,RAND() * @v_EmpCount) + 1
/* Fetch the winner's record */
FETCH ABSOLUTE @v_WinnerRow FROM c_RandomEmployee INTO @v_EmpID,
@v_EmpName
SELECT @v_Msg = 'The lucky winner as on ' +
CONVERT(VARCHAR, GETDATE(), 107) +
' is ' + @v_EmpName + ' Employee # ' +
CONVERT(VARCHAR, @v_EmpID)
PRINT @v_Msg
END
/* Close and deallocate the cursor */
CLOSE c_RandomEmployee
DEALLOCATE c_RandomEmployee
GO

--Listing 10.1: 
BEGIN TRANSACTION
UPDATE Products SET UnitPrice = 20 WHERE ProductID = 1
IF @@ERROR <> 0
BEGIN
ROLLBACK TRANSACTION
PRINT ('Transaction rolled back due to an error!')
RETURN
END
COMMIT TRANSACTION

--Listing 10.2: 
ALTER TABLE Products WITH NOCHECK ADD CONSTRAINT CK_Products_UnitPrice
CHECK (UnitPrice >= 0)

--Listing 10.3: 
ALTER TABLE Products WITH NOCHECK ADD CONSTRAINT CK_Products_UnitsInStock
CHECK (UnitsInStock >= 0)

--Listing 10.4: 
BEGIN TRANSACTION TransactA
UPDATE Products SET UnitsOnOrder = 100 WHERE ProductID = 1
SAVE TRANSACTION Savepoint1
UPDATE Products SET UnitsInStock = UnitsInStock - UnitsOnOrder WHERE ProductID = 2
IF (@@ERROR = 547)
BEGIN
ROLLBACK TRANSACTION Savepoint1
END
ELSE
COMMIT TRANSACTION


--Listing 11.4: 

CREATE PROCEDURE DMLInsertProducts
AS
DECLARE @er int
INSERT INTO Products (ProductID,SupplierID,UnitPrice,UnitsInStock,
UnitsOnOrder,ReorderLevel,Discontinued)
VALUES (6,108,13,40,70,20,0)
SELECT @er=@@ERROR
IF @er =547
BEGIN
PRINT 'An error occurred due to CHECK or FOREIGN KEY constraint violation.'
PRINT @er
RETURN
END
IF @er =515
BEGIN
PRINT 'Attempt to insert null value in a non-null column failed.'
PRINT @er
RETURN
END
GO


--Listing 11.5: 

EXECUTE DMLInsertProducts


--Listing 11.5: 

CREATE PROCEDURE DMLDeleteProducts
AS
DROP TABLE Products
DECLARE @er int
SET @er =@@ERROR
IF @er <> 0
BEGIN
RAISERROR ('An error occurred while deleting the Products table',10,1)
END


--Listing 11.6: 

EXECUTE DMLDeleteProducts


--Listing 11.7: 

sp_addmessage @msgnum =50002,
@severity =10,
@msgtext ='An error occurred while deleting the Customers table'


--Listing 11.9: 

ALTER TABLE Products WITH NOCHECK ADD CONSTRAINT CK_Products_UnitPrice
CHECK (([UnitPrice] >= 0))
GO
ALTER TABLE Products CHECK CONSTRAINT CK_Products_UnitPrice
GO


--Listing 11.10: 

BEGIN TRANSACTION
USE Inventory
BEGIN TRY
UPDATE Products SET UnitPrice=-21 WHERE ProductID=1
UPDATE Products SET UnitPrice=22 WHERE ProductID=2
COMMIT TRANSACTION
END TRY
BEGIN CATCH
PRINT 'Error occurred in the UPDATE statement. Transaction rolled back'
ROLLBACK TRANSACTION
END CATCH


--Listing 11.11: 

BEGIN TRANSACTION
USE Inventory
BEGIN TRY
UPDATE products SET unitprice=-21 WHERE productid=1
UPDATE products SET unitprice=22 WHERE productid=2
COMMIT TRANSACTION
END TRY
BEGIN CATCH
PRINT 'Error occurred in the UPDATE statement. Transaction rolled back'
SELECT ERROR_NUMBER()AS 'Error Number',
ERROR_MESSAGE()AS 'Description',
ERROR_LINE()AS 'Error Line Number',
ERROR_SEVERITY()AS 'Error Severity Level'
ROLLBACK TRANSACTION
END CATCH


--Listing 11.12: 

EXEC sp_addmessage
@msgnum = 56001,
@msgtext = N'Procedure: This operation cannot be performed on %s table',
@severity = 14, @lang = 'us_english',
@with_log = true
RAISERROR(56001,14,1,'Employees','Insert')


--Listing 11.13: 

EXEC master..xp_logevent 60000,'Test message'


--Listing 11.14: 

RAISERROR ('An error occured',14,1) WITH LOG


--Listing 11.15: 

CREATE Procedure GetTotal
(
@num1 int,
@total int OUTPUT
)
AS
DECLARE @num2 int
SET @total = @num1 + @num2
RETURN


--Listing 11.16: 

DECLARE @num int
EXEC GetTotal 5,@num OUTPUT
SELECT @num


--Listing 11.17: 

ALTER Procedure GetTotal
(
@num1 int,
@total int OUTPUT
)
AS
DECLARE @num2 int = 0
SET @total = @num1 + @num2
RETURN




--Listing 16.12: 

Use Inventory
GO
CREATE TABLE Shipper_New
(
ShipperID int,
ShipperCompanyName nvarchar(40),
ShipperPhone nvarchar(25)
)


--Listing 16.17: 

BULK INSERT Inventory.dbo.Shippers_New
FROM 'D:\Shippers.bcp'
WITH (FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n')


--Listing 21.1: 
CREATE PARTITION FUNCTION Emp_PartFunction (int)
AS RANGE LEFT
FOR VALUES (1970, 1980, 1990, 2000)

--Listing 21.2: 
CREATE PARTITION SCHEME Emp_PartScheme
AS PARTITION Emp_PartFunction
TO (Filegroup1, Filegroup2, Filegroup3, Filegroup4, Filegroup5)

--Listing 21.3: 
CREATE TABLE Emp (FName nvarchar(20), LName nvarchar(20), Yr_of_Joining int)
ON Emp_PartScheme (Yr_of_Joining)

--Listing 21.4: 
INSERT INTO Emp(FName, LName, Yr_of_Joining)
VALUES('Joleen', 'Mathews', 1965), ('Christeen', 'Ferrari', 1976), ('Mark',
'Thomson', 1982), ('Maria', 'Joseph', 1994), ('Ariya', 'Vincent', 2002), ('Peter',
'Anthony', 2008)

--Listing 21.5: 
SELECT * FROM Emp

--Listing 21.6: 
SELECT $partition.Emp_PartFunction(Yr_of_Joining) AS Partition, COUNT(*) AS
No_of_Rows FROM Emp
GROUP BY $PARTITION.Emp_PartFunction(Yr_of_Joining)
ORDER BY Partition


--Listing 24.1: 
CREATE RESOURCE POOL samplePool
WITH (MAX_CPU_PERCENT = 50,
MAX_MEMORY_PERCENT = 50)

--Listing 24.2: 
CREATE WORKLOAD GROUP sampleWorkload
WITH (IMPORTANCE = HIGH)
USING samplePool

--Listing 24.3: 
CREATE FUNCTION sampleClassFunction()
RETURNS SYSNAME
WITH SCHEMABINDING
AS
BEGIN
DECLARE @wkldgroup SYSNAME
IF (APP_NAME() = 'Resource Governance')
SET @wkldgroup = 'sampleWorkload'
ELSE
RETURN NULL
RETURN @wkldgroup
END

--Listing 24.4: 
ALTER RESOURCE GOVERNOR
WITH (CLASSIFIER_FUNCTION = dbo.sampleClassfunction)
ALTER RESOURCE GOVERNOR RECONFIGURE

--Listing 24.5: 
SELECT * FROM sys.dm_os_performance_counters
WHERE object_name IN
('SQLServer:Workload Group Stats', 'SQLServer:Resource Pool Stats')
AND instance_name = 'default'

--Listing 24.6: 
SELECT * FROM sys.dm_resource_governor_workload_groups
SELECT * FROM sys.dm_resource_governor_resource_pools
SELECt * FROM sys.dm_resource_governor_configuration

--Listing 24.7: 
SELECT * FROM sys.resource_governor_workload_groups
SELECT * FROM sys.resource_governor_resource_pools
SELECt * FROM sys.resource_governor_configuration



--Listing 25.25: 

CREATE LOGIN James WITH PASSWORD = 'abcdefgh'


--Listing 25.26: 

CREATE DATABASE CustomerData
WITH Db_CHAINING ON
CREATE DATABASE MailList
WITH DB_CHAINING ON
GO


--Listing 25.27: 

USE CustomerData
CREATE TABLE Customers
(
CustomerID int IDENTITY PRIMARY KEY,
FirstName nvarchar(255) NOT NULL,
LastName nvarchar(255) NOT NULL,
Email varchar(255) NOT NULL
)
USE MailList
CREATE TABLE EmailIDs
(
ContactID int IDENTITY PRIMARY KEY,
Email varchar(255) NOT NULL
)


--Listing 25.28: 

USE CustomerData
INSERT INTO Customers VALUES ('John','Williams','John.Williams@abcd.com')
INSERT INTO Customers VALUES ('Joseph','Walker','JosephW@xyz.com')
GO
USE MailList
INSERT INTO EmailIDs VALUES('price@abcd.com')
INSERT INTO EmailIDs VALUES('rate@xyz.com')
GO


--Listing 25.29: 

CREATE VIEW vGetAllContactEmails
AS
SELECT Email FROM EmailIDs
UNION
SELECT Email FROM CustomerData.dbo.Customers
GO


--Listing 25.30: 

Use CustomerData
CREATE USER James FOR LOGIN James
Use MailList
CREATE USER James FOR LOGIN James
GRANT SELECT ON vGetAllContactEmails TO James
GO
SETUSER 'James'
SELECT * FROM vGetAllContactEmails
SETUSER


--Listing 25.34: 

USE Inventory
GO
CREATE ASSEMBLY Class1
FROM 'C:\Users\Sumita\Desktop\ImplementingCAS\ImplementingCAS\Class1.dll'
WITH PERMISSION_SET = EXTERNAL_ACCESS
GO


--Listing 25.35: 

CREATE PROCEDURE uspGetEmployeeDetails @filename nvarchar(255)
AS EXTERNAL NAME Class1.
[ImplementingCAS.Class1].GetEmployeeDetails
GO


--Listing 25.36: 

EXEC uspGetEmployeeDetails 'C:\Personnames.txt'


--Listing 25.37: 

CREATE SYMMETRIC KEY TestSymKey
WITH ALGORITHM = AES_256
ENCRYPTION BY PASSWORD = 'test@1234'


--Listing 25.38: 

OPEN SYMMETRIC KEY TestSymKey
DECRYPTION BY PASSWORD = 'test@1234'


--Listing 25.39: 

DECLARE @Text varchar(100)
DECLARE @EncryptedText varbinary(150)
DECLARE @DecryptedText varchar(100)
SET @Text = 'Text for encrypting'
SET @EncryptedText = ENCRYPTBYKEY(KEY_GUID('TestSymKey'), @Text)
PRINT @EncryptedText


--Listing 25.40: 

SET @DecryptedText = CAST(DECRYPTBYKEY(@EncryptedText) As Varchar(100))
PRINT @DecryptedText


--Listing 25.41: 

CLOSE SYMMETRIC KEY TestSymKey


--Listing 25.42: 

CREATE MASTER KEY
ENCRYPTION BY PASSWORD = 'test@1234'


--Listing 25.43: 

CREATE ASYMMETRIC KEY TestAsymKey
WITH ALGORITHM = RSA_512


--Listing 25.44: 

DECLARE @Text varchar(100)
DECLARE @EncryptedText varbinary(150)
DECLARE @DecryptedText varchar(100)
SET @Text = 'Text for encrypting'
SET @EncryptedText = ENCRYPTBYAsymKEY(AsymKey_ID('TestAsymKey'), @Text)
PRINT @EncryptedText


--Listing 25.45: 

SET @DecryptedText = CAST(DecryptByAsymKey(AsymKey_ID('TestAsymKey'),
@EncryptedText) As Varchar(100))
PRINT @DecryptedText


--Listing 25.46: 

Use Master
GO
CREATE MASTER KEY
ENCRYPTION BY PASSWORD = 'test@1234'
GO
CREATE CERTIFICATE SQL_certificate
WITH SUBJECT = 'Server Certificate',
EXPIRY_DATE = '2020-12-1'
GO


--Listing 25.47: 

Use Inventory
CREATE DATABASE ENCRYPTION KEY
WITH ALGORITHM = AES_128
ENCRYPTION BY SERVER CERTIFICATE SQL_certificate
GO


--Listing 25.48: 

Use Master
GO
BACKUP CERTIFICATE SQL_certificate
TO FILE = 'C:\cert.cer'
WITH PRIVATE KEY (
FILE = 'C:\cert.pvk',
ENCRYPTION BY PASSWORD = 'kogent@123')


--Listing 25.49: 

Use Master
select * from sys.dm_database_encryption_keys

--Listing 30.1: 
CREATE TABLE Authors(au_id varchar(11), au_lname varchar(20), au_fname
varchar(20))

--Listing 30.2: 
DECLARE @idoc int
DECLARE @doc varchar(1000)
SET @doc ='
<ROOT>
<Authors>
<au_id>238-95-7766</au_id>
<au_lname>Carson</au_lname>
<au_fname>Cheryl</au_fname>
</Authors>
<Authors>
<au_id>722-51-5454</au_id>
<au_lname>DeFrance</au_lname>
<au_fname>Michel</au_fname>
</Authors>
<Authors>
<au_id>527-72-3246</au_id>
<au_lname>Greene</au_lname>
<au_fname>Morningstar</au_fname>
</Authors>
<Authors>
<au_id>846-92-7186</au_id>
<au_lname>Hunter</au_lname>
<au_fname>Sheryl</au_fname>
</Authors>
<Authors>
<au_id>756-30-7391</au_id>
<au_lname>Karsen</au_lname>
<au_fname>Livia</au_fname>
</Authors>
</ROOT>'
EXEC sp_xml_preparedocument @idoc OUTPUT, @doc
INSERT INTO Authors(au_id, au_lname, au_fname)
SELECT au_id, au_lname, au_fname
FROM OPENXML(@idoc, '/ROOT/Authors', 2)
WITH (au_id varchar(11),
au_lname varchar(20),
au_fname varchar(20)
)
EXEC sp_xml_removedocument @idoc

--Listing 30.3: 
SELECT * FROM Authors

--Listing 30.4: 
SELECT * FROM Authors FOR XML RAW

--Listing 30.5: 
SELECT * FROM Authors FOR XML AUTO

--Listing 30.6: 
SELECT 1 as Tag,
NULL as Parent,
au_id as [Author!1!au_id],
au_lname as [Author!1]
FROM Authors FOR XML EXPLICIT

--Listing 30.7:
SELECT * FROM Authors FOR XML PATH

--Listing 30.8: 
DECLARE @x xml
DECLARE @y bit
SET @x = '<ROOT>
<Authors au_id="238-95-7766" au_lname="Carson" au_fname="Cheryl" />
<Authors au_id="722-51-5454" au_lname="DeFrance" au_fname="Michel" />
<Authors au_id="527-72-3246" au_lname="Greene" au_fname="Morningstar" />
<Authors au_id="846-92-7186" au_lname="Hunter" au_fname="Sheryl" />
<Authors au_id="756-30-7391" au_lname="Karsen" au_fname="Livia" />
</ROOT>'
SET @y = @x.exist('/ROOT/Authors[@au_id eq xs:string("846-92-7186")]')
SELECT @y

--Listing 30.9: 
DECLARE @x xml
DECLARE @y int
SET @x = '<ROOT>
<Authors au_id="101" au_lname="Carson" au_fname="Cheryl" />
<Authors au_id="102" au_lname="DeFrance" au_fname="Michel" />
<Authors au_id="103" au_lname="Greene" au_fname="Morningstar" />
<Authors au_id="104" au_lname="Hunter" au_fname="Sheryl" />
<Authors au_id="105" au_lname="Karsen" au_fname="Livia" />
</ROOT>'
SET @y = @x.value('(/ROOT/Authors/@au_id)[2]', 'int' )
SELECT @y

--Listing 30.10: 
DECLARE @x xml
SET @x = '<ROOT>
<Authors>
<au_id>238-95-7766</au_id>
<Name>
<au_lname>Carson</au_lname>
<au_fname>Cheryl</au_fname>
</Name>
</Authors>
<Authors>
<au_id>722-51-5454</au_id>
<Name>
<au_lname>DeFrance</au_lname>
<au_fname>Michel</au_fname>
</Name>
</Authors>
<Authors>
<au_id>527-72-3246</au_id>
<Name>
<au_lname>Greene</au_lname>
<au_fname>Morningstar</au_fname>
</Name>
</Authors>
<Authors>
<au_id>846-92-7186</au_id>
<Name>
<au_lname>Hunter</au_lname>
<au_fname>Sheryl</au_fname>
</Name>
</Authors>
<Authors>
<au_id>756-30-7391</au_id>
<Name>
<au_lname>Karsen</au_lname>
<au_fname>Livia</au_fname>
</Name>
</Authors>
</ROOT>'
SELECT @x.query('/ROOT/Authors/Name')

--Listing 30.11: 
DECLARE @x xml
SET @x='<ROOT>
<Authors au_id="238-95-7766" au_lname="Carson" au_fname="Cheryl" />
<Authors au_id="722-51-5454" au_lname="DeFrance" au_fname="Michel" />
<Authors au_id="527-72-3246" au_lname="Greene" au_fname="Morningstar" />
<Authors au_id="846-92-7186" au_lname="Hunter" au_fname="Sheryl" />
<Authors au_id="756-30-7391" au_lname="Karsen" au_fname="Livia" />
</ROOT>'
SELECT T.C.query('.') AS result
FROM @x.nodes('/ROOT/Authors') T(C)

--Listing 30.12: 
DECLARE @x xml
SET @x = '<ROOT>
<Authors>
<au_id>238-95-7766</au_id>
<au_lname>Carson</au_lname>
<au_fname>Cheryl</au_fname>
</Authors>
<Authors>
<au_id>722-51-5454</au_id>
<au_lname>DeFrance</au_lname>
<au_fname>Michel</au_fname>
</Authors>
<Authors>
<au_id>527-72-3246</au_id>
<au_lname>Greene</au_lname>
<au_fname>Morningstar</au_fname>
</Authors>
<Authors>
<au_id>846-92-7186</au_id>
<au_lname>Hunter</au_lname>
<au_fname>Sheryl</au_fname>
</Authors>
</ROOT>'
SET @x.modify('
insert <au_phone>(408) 555-5472</au_phone>
as last into (/ROOT/Authors)[1]')
SELECT @x

--Listing 30.13: 
DECLARE @x xml
SET @x = '<ROOT>
<Authors>
<au_id>238-95-7766</au_id>
<au_lname>Carson</au_lname>
<au_fname>Cheryl</au_fname>
<au_phone>(408) 555-5472</au_phone>
</Authors>
<Authors>
<au_id>722-51-5454</au_id>
<au_lname>DeFrance</au_lname>
<au_fname>Michel</au_fname>
</Authors>
<Authors>
<au_id>527-72-3246</au_id>
<au_lname>Greene</au_lname>
<au_fname>Morningstar</au_fname>
</Authors>
<Authors>
<au_id>846-92-7186</au_id>
<au_lname>Hunter</au_lname>
<au_fname>Sheryl</au_fname>
</Authors>
</ROOT>'
SET @x.modify('delete(/ROOT/Authors[1]/au_phone)')
SELECT @x

--Listing 30.14: 
DECLARE @x xml
SET @x = '<ROOT>
<Authors>
<au_id>238-95-7766</au_id>
<au_lname>Carson</au_lname>
<au_fname>Cheryl</au_fname>
</Authors>
<Authors>
<au_id>722-51-5454</au_id>
<au_lname>DeFrance</au_lname>
<au_fname>Michel</au_fname>
</Authors>
<Authors>
<au_id>527-72-3246</au_id>
<au_lname>Greene</au_lname>
<au_fname>Morningstar</au_fname>
</Authors>
<Authors>
<au_id>846-92-7186</au_id>
<au_lname>Hunter</au_lname>
<au_fname>Sheryl</au_fname>
</Authors>
</ROOT>'
SET @x.modify('replace value of (/ROOT/Authors[1]/au_id/text())[1] with "101-10-
1001"')
SELECT @x


--Listing 31.1: 
sp_configure 'show advanced options', 1
GO
RECONFIGURE
GO
sp_configure 'clr enabled', 1
GO
RECONFIGURE
GO

--Listing 31.3: 
exec GetOrdersCustomers
@DestinationCountry = 'USA'


